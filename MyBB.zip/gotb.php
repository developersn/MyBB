<?php
session_start();
define("IN_MYBB", "1");
require("./global.php");
// Security
@session_start();
$sec = uniqid();
$md = md5($sec.'vm');
// Security

$num = $_POST['sn_num'];
$query = $db->query("SELECT * FROM ".TABLE_PREFIX."sn WHERE num={$num}");
$sn = $db->fetch_array($query);

$callBackUrl = $mybb->settings['bburl'] . '/sn_verfy.php?num=' .$sn['num'].'&md='.$md.'&sec='.$sec;

	
$data_string = json_encode(array(
'pin'=> $mybb->settings['api_sn'],
'price'=> $sn['price'],
'callback'=> $callBackUrl ,
'order_id'=> $num,
'ip'=> $_SERVER['REMOTE_ADDR'],
'callback_type'=>2
));

$ch = curl_init('https://developerapi.net/api/v1/request');
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Content-Type: application/json',
'Content-Length: ' . strlen($data_string))
);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
$result = curl_exec($ch);
curl_close($ch);


$json = json_decode($result,true);
if(!empty($json['result']) AND $json['result'] == 1)
{
       // Set Session
$_SESSION[$sec] = [
	'price'=>$amount ,
	'order_id'=>$invoice_id ,
	'au'=>$json['au'] ,
];
		  echo ('<div style="display:none">'.$json['form'].'</div>Please wait ... <script language="javascript">document.payment.submit(); </script>');
}else{
$res=$json['msg'];
	
	echo '<meta charset=utf-8><font color=red> خطا (' . $res . ') : ' . $prompt . '</font>';
}
?>